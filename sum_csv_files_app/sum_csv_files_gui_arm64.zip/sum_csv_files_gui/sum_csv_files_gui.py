#!/usr/bin/env python3
"""
2) would it be possible to allow users to cut small rectangular boxes (3 to 6)
out of a single csv file - edit those files, then add them up afterwards - these
would be matrix boxes for different ion charge states to which I'll need to
adjust for their PAPS&DV varying efficiencies. It would be very, very helpful
and useful - and save a lot of time - I would be happy to test it with spot
checks, hand calculation, etc. as much as needed in the process. 
"""

import re
import sys
from itertools import chain

import pandas as pd
from pathlib import Path
import PySimpleGUI as sg

_files = []
_full_region = None
_regions = dict()
_adjustments = dict()


def get_files():
    return sg.popup_get_file('CSV Files', 'Goobers',
                             no_window=True,
                             multiple_files=True,
                             file_types=(('CSV Files', '*.csv'),)
                             )


def make_layout():
    return [[sg.Text('Regions', font='default 17 bold'),
             sg.Button('New Region', font='default, 12', key='-NEWRGN-'),
             sg.Button('Reset', font='default, 12', key='-RESETRGN-')],
            [[sg.Text('name'), sg.Input(name, size=(6, 1), key=f'-NAME{name}-'),
              sg.Text('xlo'), sg.Input(xrng[0], size=(6, 1), key=f'-XLO{name}-'),
              sg.Text('xhi'), sg.Input(xrng[1], size=(6, 1), key=f'-XHI{name}-'),
              sg.Text('ylo'), sg.Input(yrng[0], size=(6, 1), key=f'-YLO{name}-'),
              sg.Text('yhi'), sg.Input(yrng[1], size=(6, 1), key=f'-YHI{name}-'),
              ]
             for name, (xrng, yrng) in _regions.items()],
            [[sg.HorizontalSeparator()],
             [sg.Text('CSV Files and Adjustments', font='default 17 bold'),
              sg.Button('Select New File', font='default, 12', key=f'-NEWFILE-'),
              sg.Button('Calculate Sums', font='default, 12', key=f'-CALCULATE-'),
              sg.Button('Reset', font='default, 12', key='-RESETFIL-')],
             ],
            [[sg.Text(csvf.stem),
              sg.Text('x', font='default 18'),
              sg.Input(_adjustments.get(csvf.stem)[0], size=(6, 1), key=f'-{csvf.stem.upper()}_FCTR-'),
              sg.Text('+', font='default 18'),
              sg.Input(_adjustments.get(csvf.stem)[1], size=(6, 1), key=f'-{csvf.stem.upper()}_OFST-'),
              sg.Text(f'= {sum_regions(csvf)[0]}', font='default 16')]
             for csvf in _files],
            [sg.T()],
            [sg.Push(),
             sg.Input(key='-SAVE-', visible=False, enable_events=True),
             sg.FileSaveAs('Save Sums'),
             sg.Button('Exit'),
             sg.Push(),]
            ]


def set_defaults(files_regions_adjustments=True, regions=True) -> None:
    global _files, _full_region, _regions, _adjustments
    sg.set_options(font='default 14')
    if files_regions_adjustments:
        _files = [Path(csvf) for csvf in get_files()]
        if len(_files) == 0:
            return
        df = pd.read_csv(_files[0], skiprows=3, index_col=0)
        _full_region = {'All': [(df.columns.min(), df.columns.max()),
                                (df.index.min(), df.index.max()), ]}
        _adjustments = {csvf.stem: (1., 0.) for csvf in _files}
    if regions:
        _regions = _full_region.copy()


def update_adjustments(values):
    """
    Update the golbal _adjustments using current values
    """
    for csvf in _files:
        key = csvf.stem.upper()
        factor = values[f'-{key}_FCTR-']
        offset = values[f'-{key}_OFST-']
        _adjustments[csvf.stem] = (factor, offset)


def update_regions(values):
    """
    Update the golbal _regions dict with current values
    """
    global _regions
    regions = dict()
    for name in _regions.keys():
        new_name = values[f'-NAME{name}-']
        if new_name == '':
            return
        xlo = values[f'-XLO{name}-']
        xhi = values[f'-XHI{name}-']
        ylo = values[f'-YLO{name}-']
        yhi = values[f'-YHI{name}-']
        regions[new_name] = [(xlo, xhi), (ylo, yhi)]
    _regions = regions


# def sum_csvs_by_cell():
#     with open(_files[0], 'rb') as csvfile:
#         l1 = csvfile.readline()
#         l2 = csvfile.readline().decode()
#         l3 = csvfile.readline()
#         csv_sum = pd.read_csv(csvfile, delimiter=',', index_col=0)
#         if re.findall(r' PHAs of [0-9,]+ total', l2):
#             tots_phas = int(re.findall(r'[0-9,]+', l2)[-1].replace(',', ''))
#         else:
#             tots_phas = 0
#     for csvfilepath in _files[1:]:
#         with open(csvfilepath, 'rb') as csvfile:
#             _ = csvfile.readline()
#             title = csvfile.readline().decode()
#             _ = csvfile.readline()
#             csv_sum += pd.read_csv(csvfile, delimiter=',', index_col=0)
#             if re.findall(r' PHAs of [0-9,]+ total', title):
#                 tots_phas += int(re.findall(r'[0-9,]+', title)[-1].replace(',', ''))
#     with open(Path(_files[0]).with_stem('sum'), 'wb') as outfile:
#         outfile.write(l1)
#         if tots_phas > 0:
#             # update total PHAs with the sum of totalPHAs
#             l2 = re.sub(r' PHAs of [0-9,]+ total', f' PHAs of {tots_phas:,} total', l2)
#         outfile.write(l2.encode())
#         outfile.write(l3)
#         csv_sum.to_csv(outfile)
#
#
def sum_regions(csvpath: Path) -> tuple[list[float], list[float]]:
    df = pd.read_csv(csvpath, skiprows=3, index_col=0)
    df.columns = df.columns.astype(float)
    factor, offset = [float(val) for val in _adjustments[csvpath.stem]]
    region_sums = []
    region_counts = []
    for (xlo, xhi), (ylo, yhi) in _regions.values():
        blob = df.loc[float(yhi):float(ylo), float(xlo):float(xhi)]
        region_counts.append(blob.count().sum())
        region_sums.append((blob * factor + offset)
                             .sum()
                             .sum()
                             .round(3)
                           )
    return region_sums, region_counts


def save_sums(values):
    filepath = Path(values['-SAVE-'])
    # create a DataFrame containing Sum & Count columns for each region and csv file
    df = pd.DataFrame((chain.from_iterable(zip(sums, counts))
                       for csvfile in _files
                       for sums, counts in [sum_regions(csvfile)]
                       ),
                      columns='zzzz'.join(f'{name}_Sumzzzz{name}_Count' for name in _regions.keys()).split('zzzz'),
                      index=_files)
    # sum to get the total sums for each region over all files
    totals = df.sum(axis=0)
    regionstr = '\t'.join([f'{name}_Sum\t{name}_Count' for name in _regions.keys()])
    with open(filepath, 'w') as outfile:
        outfile.write(f'Boxes\nBox\txlo\txhi\tylo\tyhi\tTotal_Sum\tTotal_Count\n')
        for name, (xlims, ylims) in _regions.items():
            limits_str = '\t'.join([f'{float(val):.4f}' for val in [*xlims, *ylims]])
            limits_str += f'\t{totals[f"{name}_Sum"].round(3)}\t{totals[f"{name}_Count"].round(3)}'
            outfile.write(f'{name}\t{limits_str}\n')
        outfile.write(f'\nSums\nFactor\tOffset\t{regionstr}\tFile\n')
        for csvfile in _files:
            factor, offset = _adjustments[csvfile.stem]
            sums_str = '\t'.join(df.loc[csvfile].astype(str))
            outfile.write(f'{float(factor):.4f}\t{float(offset):.4f}\t{sums_str}\t{csvfile}\n')


def main(args):
    global _files, _regions
    set_defaults()
    exit_program = False
    while not exit_program:
        window = sg.Window('Sum CSV Files Version 1.1.0', layout=make_layout(), relative_location=(0, 0))
        while True:
            event, values = window.read()
            # sg.Print(event, values)
            if event in [sg.WIN_CLOSED, 'Exit']:
                exit_program = True
                break
            update_adjustments(values=values)
            update_regions(values=values)
            if event == '-NEWFILE-':
                newfiles = get_files()
                if newfiles:
                    newfiles = [Path(newf) for newf in newfiles if Path(newf) not in _files]
                    _files.extend(newfiles)
                    _adjustments.update({csvf.stem: (1., 0.) for csvf in newfiles})
                    window.close()
                    break
            elif event == '-CALCULATE-':
                window.close()
                break
            elif event == '-RESETFIL-':
                set_defaults(regions=False)
                window.close()
                break
            elif event == '-NEWRGN-':
                if 'New' in _regions.keys():
                    sg.Popup(f'Region name New is already in use.  Rename the region before creating a new one')
                else:
                    _regions['New'] = _full_region['All']
                window.close()
                break
            elif event == '-RESETRGN-':
                set_defaults(files_regions_adjustments=False)
                window.close()
                break
            elif event == '-SAVE-':
                save_sums(values)
                window.close()
                break
    window.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv))
