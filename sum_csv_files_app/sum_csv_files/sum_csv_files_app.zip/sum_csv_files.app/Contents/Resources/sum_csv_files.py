#!/usr/bin/env python3
import os
import sys

import numpy as np
from pathlib import Path


def main(args):
    if len(args) < 2:
        args.extend(Path(os.getcwd()).parents[2].glob('*.csv'))
    if len(args) < 2:
        return
    with open(args[1], 'r') as csvfile:
        _ = csvfile.readline()
        _ = csvfile.readline()
        _ = csvfile.readline()
        csv_sum = np.genfromtxt(csvfile, delimiter=',')
        colndx = csv_sum[0, :].copy()  # column names
        rowndx = csv_sum[:, 0].copy()  # row names
    for csvarg in args[2:]:
        with open(csvarg, 'r') as csvfile:
            l1 = csvfile.readline()
            l2 = csvfile.readline()
            l3 = csvfile.readline()
            csv_sum += np.genfromtxt(csvfile, delimiter=',')
    csv_sum[0, :] = colndx
    csv_sum[:, 0] = rowndx
    with open(Path(args[1]).with_stem('sum'), 'w') as outfile:
        outfile.write(l1)
        outfile.write(l2)
        outfile.write(l3)
        np.savetxt(outfile, csv_sum, fmt='%.4e', delimiter=',')


if __name__ == '__main__':
    sys.exit(main(sys.argv))
