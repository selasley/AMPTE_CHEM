sum_csv_files_gui.app is a small application created by py2app that will allow the user
to open one or more csv files and define regions of interest.  Sums of values in each 
region are calculated for each file and the information can be saved to a text file.  The 
values in each region can be adjusted by multiplying each value by a user entered factor 
and adding a user entered offset.

To use, double click on the app icon.  This will bring up an open files dialog that will 
allow you to open one or more csv files.  The files should be in the format of the 2D 
histogram csv files from the AMPTE Web App.  

Top area of the window for Regions:
Use the New Region button to add a new region to the list of regions.
Use the Reset button to reset the list to a single region covering the entire range of
the first csv file opened. 


Bottom area of the window for Files and Adjustments:
Use the Select New File button to open one ore more additional csv files and add them
to the list.  
Use the Reset button to remove all csv files from the list and open the open files dialog.  
Use the Calculate Sums button to re-calculate the sums shown in brackets after changes 
are made to inputs.


Use the Save Sums button to save region, adjustment, sums, count of values and file names
to a text file.
Use the Exit button or click the red close window button to exit the program.

Let me know if you have questions or suggestions about the app.

Scott   slasley@umd.edu, NOT slasley@space.umd.edu

------------------------------------------------------------------------------------------
To make the app from sum_csv_files_gui.py
1) Install python 3.11 using the installer from https://www.python.org
2) Create a virtual environment with the command

python3.11 -m venv --copies p2aenv

3) Launch the virtual environment and install the necessary python packages with these
   commands

source p2aenv/bin/activate
pip3 install -U pip setuptools wheel certifi
pip3 install -r requirements.txt

4) If you want to distribute the app to Macs without python 3.11 installed, copy the tcl 
   and tk directories to the virtual environment

rsync -av /Library/Frameworks/Python.framework/Versions/3.11/lib/tcl8* p2aenv/lib/
rsync -av /Library/Frameworks/Python.framework/Versions/3.11/lib/tk8* p2aenv/lib/

5) If you don't want to use the existing setup.py file you can create a new one with the 
   command

py2applet --make-setup sum_csv_files_gui.py

6) Remove any existing build and dist folders then create the app with the command

python3 setup.py py2app
